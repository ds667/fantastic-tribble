const gameArea = document.getElementById('game-area');
const basket = document.getElementById('basket');
const scoreDisplay = document.getElementById('score');
const livesDisplay = document.getElementById('lives');
let score = 0;
let lives = 3;
let fallSpeed = 5; // Base fall speed
let spawnInterval = 1000; // Initial interval between fruits

function moveBasket(event) {
    const gameAreaRect = gameArea.getBoundingClientRect();
    let basketX = event.clientX - gameAreaRect.left - basket.offsetWidth / 2;

    if (basketX < 0) {
        basketX = 0;
    } else if (basketX > gameAreaRect.width - basket.offsetWidth) {
        basketX = gameAreaRect.width - basket.offsetWidth;
    }

    basket.style.left = `${basketX}px`;
}

function createFruit() {
    const fruit = document.createElement('div');
    const fruitSize = getRandomFruitSize();
    fruit.className = `fruit ${fruitSize}`;
    const maxX = gameArea.clientWidth - getFruitWidth(fruitSize);
    fruit.style.left = `${Math.random() * maxX}px`;
    gameArea.appendChild(fruit);

    let sidewaysMovement = Math.random() > 0.5 ? 1 : -1;
    const fallInterval = setInterval(() => {
        fruit.style.top = `${fruit.offsetTop + fallSpeed}px`;

        let fruitX = parseInt(fruit.style.left) + sidewaysMovement;
        if (fruitX < 0 || fruitX > maxX) {
            sidewaysMovement *= -1; // Reverse direction if hitting boundaries
        }
        fruit.style.left = `${fruitX}px`;

        const fruitRect = fruit.getBoundingClientRect();
        const basketRect = basket.getBoundingClientRect();

        if (fruitRect.top > gameArea.clientHeight) {
            gameArea.removeChild(fruit);
            clearInterval(fallInterval);
            loseLife();
        } else if (
            fruitRect.bottom >= basketRect.top &&
            fruitRect.left >= basketRect.left &&
            fruitRect.right <= basketRect.right
        ) {
            gameArea.removeChild(fruit);
            clearInterval(fallInterval);
            increaseScore();
        }
    }, 50);
}

function getRandomFruitSize() {
    const sizes = ['small', 'medium', 'large'];
    return sizes[Math.floor(Math.random() * sizes.length)];
}

function getFruitWidth(size) {
    switch (size) {
        case 'small': return 20;
        case 'medium': return 30;
        case 'large': return 40;
    }
}

function increaseScore() {
    score += 10;
    scoreDisplay.textContent = `Score: ${score}`;

    // Increase difficulty
    if (score % 50 === 0 && fallSpeed < 20) {
        fallSpeed += 1;
    }
    if (score % 100 === 0 && spawnInterval > 300) {
        clearInterval(gameInterval);
        spawnInterval -= 100;
        gameInterval = setInterval(createFruit, spawnInterval);
    }
}

function loseLife() {
    lives -= 1;
    livesDisplay.textContent = `Lives: ${lives}`;
    if (lives === 0) {
        alert(`Game Over! Your score is ${score}`);
        resetGame();
    }
}

function resetGame() {
    score = 0;
    lives = 3;
    fallSpeed = 5;
    spawnInterval = 1000;
    scoreDisplay.textContent = `Score: ${score}`;
    livesDisplay.
